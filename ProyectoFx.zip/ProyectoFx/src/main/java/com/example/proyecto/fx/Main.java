package com.example.proyecto.fx;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class Main extends Application {

    private ObservableList<String> listaProductos;
    private FirebaseService firebaseService;

    @Override
    public void start(Stage primaryStage) {
        listaProductos = FXCollections.observableArrayList();

        try {
            firebaseService = new FirebaseService();
        } catch (IOException ex) {
            mostrarAlerta("Error al conectar con Firebase: " + ex.getMessage());
        }

        TextField campoNombre = new TextField();
        campoNombre.setPromptText("Nombre del producto");

        TextField campoCantidad = new TextField();
        campoCantidad.setPromptText("Cantidad");

        TextField campoPrecio = new TextField();
        campoPrecio.setPromptText("Precio");

        Button botonAgregar = new Button("Agregar");
        Button botonEliminar = new Button("Eliminar seleccionado");
        Button botonEditar = new Button("Editar producto");

        ListView<String> vistaLista = new ListView<>(listaProductos);

        botonAgregar.setOnAction(e -> Optional.of(new String[]{campoNombre.getText().trim(), campoCantidad.getText().trim(), campoPrecio.getText().trim()})
                .filter(campos -> Stream.of(campos).allMatch(((Predicate<String>) String::isEmpty).negate()))
                .map(campos -> {
                    try {
                        int cant = Integer.parseInt(campos[1]);
                        double pre = Double.parseDouble(campos[2]);
                        return new Object[]{formatearProducto(campos[0], cant, pre), campos[0], cant, pre};
                    } catch (NumberFormatException ex) {
                        mostrarAlerta("Cantidad y precio deben ser números válidos.");
                        return null;
                    }
                })
                .filter(data -> data != null)
                .ifPresent(data -> {
                    String producto = (String) data[0];
                    String nombre = (String) data[1];
                    int cant = (int) data[2];
                    double pre = (double) data[3];
                    listaProductos.add(producto);
                    campoNombre.clear();
                    campoCantidad.clear();
                    campoPrecio.clear();
                    firebaseService.guardarProducto(nombre, cant, pre);
                })
        );

        botonEliminar.setOnAction(e -> Optional.ofNullable(vistaLista.getSelectionModel().getSelectedItem())
                .ifPresent(seleccion -> {
                    String nombreEliminar = extraerNombre(seleccion);
                    firebaseService.eliminarProducto(nombreEliminar);
                    listaProductos.remove(seleccion);
                }));

        botonEditar.setOnAction(e -> Optional.of(vistaLista.getSelectionModel().getSelectedIndex())
                .filter(i -> i >= 0)
                .map(i -> new Object[]{i, listaProductos.get(i)})
                .ifPresent(data -> {
                    int index = (int) data[0];
                    String seleccionado = (String) data[1];
                    String nombreAntiguo = extraerNombre(seleccionado);

                    Optional<String> nuevoNombre = new TextInputDialog(nombreAntiguo).showAndWait();
                    Optional<String> nuevaCantidadStr = new TextInputDialog(String.valueOf(extraerCantidad(seleccionado))).showAndWait();
                    Optional<String> nuevoPrecioStr = new TextInputDialog(String.valueOf(extraerPrecio(seleccionado))).showAndWait();

                    nuevoNombre.flatMap(nom -> nuevaCantidadStr.flatMap(cantStr -> nuevoPrecioStr.map(preStr -> {
                        try {
                            int nuevaCantidad = Integer.parseInt(cantStr);
                            double nuevoPrecio = Double.parseDouble(preStr);
                            String formateado = formatearProducto(nom.trim(), nuevaCantidad, nuevoPrecio);

                            // Actualiza el producto en Firebase
                            firebaseService.actualizarProducto(nombreAntiguo, nom.trim(), nuevaCantidad, nuevoPrecio);

                            return formateado;
                        } catch (NumberFormatException ex) {
                            mostrarAlerta("La cantidad o precio ingresados no son válidos.");
                            return null;
                        }
                    }))).ifPresent(productoEditado -> listaProductos.set(index, productoEditado));
                })
        );

        VBox campos = new VBox(5, campoNombre, campoCantidad, campoPrecio, botonAgregar);
        VBox panel = new VBox(10, campos, vistaLista, botonEditar, botonEliminar);
        panel.setPadding(new Insets(15));

        Scene escena = new Scene(panel, 400, 500);
        primaryStage.setTitle("Gestor de Productos");
        primaryStage.setScene(escena);
        primaryStage.show();
    }

    private String formatearProducto(String nombre, int cantidad, double precio) {
        return nombre + " | Cantidad: " + cantidad + " | Precio: $" + String.format("%.2f", precio);
    }

    private void mostrarAlerta(String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.WARNING);
        alerta.setTitle("Datos incorrectos");
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }

    private String extraerNombre(String texto) {
        return texto.split(" \\| ")[0];
    }

    private int extraerCantidad(String texto) {
        String parte = texto.split("Cantidad: ")[1];
        return Integer.parseInt(parte.split(" \\| ")[0]);
    }

    private double extraerPrecio(String texto) {
        String parte = texto.split("Precio: \\$")[1];
        parte = parte.replace(",", ".");
        return Double.parseDouble(parte);
    }

    public static void main(String[] args) {
        launch(args);
    }
}