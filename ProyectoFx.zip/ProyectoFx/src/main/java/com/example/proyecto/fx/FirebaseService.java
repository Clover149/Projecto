package com.example.proyecto.fx;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.database.*;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;

public class FirebaseService {

    private final DatabaseReference dbRef;

    public FirebaseService() throws IOException {
        FileInputStream serviceAccount = new FileInputStream(
                "C:\\Users\\Gm117 6\\Documents\\fire\\gestorproductos-aa5ce-firebase-adminsdk-fbsvc-90415e68fd.json"
        );

        FirebaseOptions options = FirebaseOptions.builder()
                .setCredentials(GoogleCredentials.fromStream(serviceAccount))
                .setDatabaseUrl("https://gestorproductos-aa5ce-default-rtdb.firebaseio.com/")
                .build();

        if (FirebaseApp.getApps().isEmpty()) {
            FirebaseApp.initializeApp(options);
        }

        dbRef = FirebaseDatabase.getInstance().getReference("productos");
    }

    public void guardarProducto(String nombre, int cantidad, double precio) {
        String key = dbRef.push().getKey();
        if (key == null) {
            System.err.println("No se pudo generar la clave para el producto");
            return;
        }

        Map<String, Object> producto = new HashMap<>();
        producto.put("nombre", nombre);
        producto.put("cantidad", cantidad);
        producto.put("precio", precio);

        dbRef.child(key).setValueAsync(producto).addListener(() -> {
            System.out.println("Producto guardado correctamente en Firebase.");
        }, Runnable::run);
    }

    public void actualizarProducto(String nombreAntiguo, String nuevoNombre, int nuevaCantidad, double nuevoPrecio) {
        // Buscar la clave del producto por nombre sin usar for explícito, con listener
        dbRef.orderByChild("nombre").equalTo(nombreAntiguo).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                snapshot.getChildren().forEach(child -> {
                    Map<String, Object> productoActualizado = new HashMap<>();
                    productoActualizado.put("nombre", nuevoNombre);
                    productoActualizado.put("cantidad", nuevaCantidad);
                    productoActualizado.put("precio", nuevoPrecio);

                    dbRef.child(child.getKey()).updateChildrenAsync(productoActualizado).addListener(() -> {
                        System.out.println("Producto actualizado correctamente en Firebase.");
                    }, Runnable::run);
                });
            }

            @Override
            public void onCancelled(DatabaseError error) {
                System.err.println("Error al actualizar producto: " + error.getMessage());
            }
        });
    }

    public void eliminarProducto(String nombre) {
        dbRef.orderByChild("nombre").equalTo(nombre).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                snapshot.getChildren().forEach(child -> {
                    dbRef.child(child.getKey()).removeValueAsync().addListener(() -> {
                        System.out.println("Producto eliminado correctamente en Firebase.");
                    }, Runnable::run);
                });
            }

            @Override
            public void onCancelled(DatabaseError error) {
                System.err.println("Error al eliminar producto: " + error.getMessage());
            }
        });
    }
}